### No longer maintained, use [hyrPulse](https://github.com/Ethical-H4CK3R/hyprPulse) instead

# Usage
python pulse.py [site] [username] [wordlist]

**python pulse.py Instagram username103 pass.lst**
